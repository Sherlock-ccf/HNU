# judge_plot.py
import sys
sys.set_int_max_str_digits(1000000)
#import random
import subprocess
import time
import statistics
import sys
from math import comb
import math

import pandas as pd
import matplotlib.pyplot as plt

class Logger:
    def __init__(self, filename):
        self.terminal = sys.stdout
        self.log = open(filename, "w", encoding="utf-8")

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        self.terminal.flush()
        self.log.flush()

    def close(self):
        self.log.close()

sys.stdout = Logger("log.txt")

# ===== 标准答案 =====
def catalan(n):
    return comb(2*n, n) // (n+1)


# ===== 运行程序 =====
def run_prog(prog, n):
    start = time.perf_counter()
    p = subprocess.run(
        [prog],
        input=f"{n}\n",
        text=True,
        capture_output=True
    )
    end = time.perf_counter()

    if p.returncode != 0:
        raise RuntimeError(p.stderr)

    return p.stdout.strip(), (end - start)*1000


# ===== log拟合 =====
def fit_log(ns, ts):
    xs = [math.log(x) for x in ns]
    ys = [math.log(y) for y in ts]

    x_mean = sum(xs)/len(xs)
    y_mean = sum(ys)/len(ys)

    num = sum((x-x_mean)*(y-y_mean) for x,y in zip(xs,ys))
    den = sum((x-x_mean)**2 for x in xs)

    a = num/den
    b = y_mean - a*x_mean
    return a, b


# ===== 主函数 =====
def main():
    if len(sys.argv) < 2:
        print("用法: python judge_plot.py 程序")
        return

    prog = sys.argv[1]

    #random.seed(20260322)

    # ===== 1. 对拍 =====
    print("开始对拍...")
    start = time.perf_counter()
    print("\n时间测试：")
    avg_times = []
    err_count = 0
    ns = list(range(1,100,1))
    for n in ns:
        #n = random.randint(1, 200)
        #ns.append(n)

        times = []
        for _ in range(20):
            _, t = run_prog(prog, n)
            times.append(t)

        avg = statistics.mean(times)
        avg_times.append(avg)

        print(f"n={n}, avg={avg:.4f} ms")

        expected = str(catalan(n))
        out, _ = run_prog(prog, n)
        print(f"out={out}")

        if out != expected:
            print("❌ 错误")
            print(n, expected, out)
            err_count += 1

    end = time.perf_counter()
    if err_count > 0:
        print(f"测试完成，共发现 {err_count} 个错误")
    else:
        print("✅ 对拍通过")
    print(f"共计用时{(end - start):.4f}s")


    # ===== 3. pandas处理 =====
    df = pd.DataFrame({
        "n": ns,
        "time": avg_times
    })
    df = df.sort_values(by="n")
    df = df.groupby("n", as_index=False).mean()

    # ===== 4. 拟合 =====
    a, b = fit_log(df["n"].tolist(), df["time"].tolist())

    print("\n复杂度拟合：")
    print(f"T(n) ≈ n^{a:.3f}")

    # ===== 5. 画图 =====

    # 图1：普通图
    plt.figure()
    plt.plot(df["n"], df["time"], marker='o')
    plt.xlabel("n")
    plt.ylabel("time (ms)")
    plt.title("Time vs n")
    plt.grid()
    plt.savefig("time_plot.png")

    # 图2：log-log图
    plt.figure()
    plt.loglog(df["n"], df["time"], marker='o', label="data")

    # 拟合线
    fit_y = [math.exp(b) * (x**a) for x in df["n"]]
    plt.loglog(df["n"], fit_y, linestyle='--', label=f"fit: n^{a:.2f}")

    plt.xlabel("log(n)")
    plt.ylabel("log(time)")
    plt.title("Log-Log Plot")
    plt.legend()
    plt.grid()
    plt.savefig("log_plot.png")

    print("\n已生成图像：")
    print("time_plot.png")
    print("log_plot.png")

    print("\n程序运行完成，日志已写入 log.txt")

if __name__ == "__main__":
    main()
