#include <bits/stdc++.h>
using namespace std;

typedef vector<int> BigInt;

void multiply(BigInt &a, int b)
{
    int carry = 0;
    for (int i = 0; i < a.size(); i++)
    {
        int t = a[i] * b + carry;
        a[i] = t % 10;
        carry = t / 10;
    }
    while (carry)
    {
        a.push_back(carry % 10);
        carry /= 10;
    }
}

void divide(BigInt &a, int b)
{
    int r = 0;
    for (int i = a.size() - 1; i >= 0; i--)
    {
        int cur = r * 10 + a[i];
        a[i] = cur / b;
        r = cur % b;
    }

    while (a.size() > 1 && a.back() == 0)
        a.pop_back();
}

int main()
{
//	freopen("cin.txt","r",stdin);
//	freopen("cout.txt","w",stdout);
    int n;
    while (cin >> n)
    {
        BigInt Cn;
        Cn.push_back(1); 
        for (int i = 0; i < n; i++)
        {
            multiply(Cn, 4 * i + 2);
            divide(Cn, i + 2);
        }
        for (int i = Cn.size() - 1; i >= 0; i--)
            cout << Cn[i];
        cout << endl;
    }
}
