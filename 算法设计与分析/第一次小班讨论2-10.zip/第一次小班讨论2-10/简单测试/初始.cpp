//#pragma GCC optimize(2)
//#include <bits/stdc++.h>
#include <iostream>
#include<queue>
#include<map>
#include<algorithm>
#include<string>
#include<math.h>
#include<map>
#include<unordered_map>
#include<vector>
#include<set>
#include<numeric>
#include<string.h>
#include<string>
#include<sstream>
using namespace std;
#define int long long
const int N=3e5+7;
const int inf=0x7ffffffffffffff;
              
void solve()//求卡特兰数
{
	int n;cin>>n;
	int Cn=1;
	for(int i=1;i<=n;i++)
	{
		Cn=Cn*(4*i-2)/(i+1);
	}
	cout<<Cn<<endl;
}
	

signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
   // freopen("cin.txt","r",stdin);
//freopen("cout.txt","w",stdout);
    int t;
    //t=1;
    cin>>t;
    while(t--)
    {
        solve();
    }
    return 0;
}


